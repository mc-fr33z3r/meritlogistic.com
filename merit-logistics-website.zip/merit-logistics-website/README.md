# Merit Logistics website

A responsive multi-page starter website built with HTML, CSS and JavaScript.

## Pages
- `index.html` — Home
- `about.html` — About the company
- `services.html` — Services
- `fleet.html` — Fleet / transport capabilities
- `contact.html` — Contact form
- `quote.html` — Request a quote form

## Run it
1. Extract the ZIP.
2. Open the `merit-logistics-website` folder.
3. Double-click `index.html`, or open the folder in VS Code and use the Live Server extension.

## Before publishing
- Replace the sample phone number, email and location in `contact.html` with official company details.
- Confirm which services Merit Logistics actually offers and edit the wording to match.
- Add real fleet photographs and verified vehicle capacities to `fleet.html`.
- The contact and quote forms are front-end demos only. Connect them to a backend, email service or form provider to receive submissions.
- The hero background uses an externally hosted Unsplash image and Google Fonts; internet access is needed for those assets.
